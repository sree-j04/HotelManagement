/*
 * sree jessu
 * customer
 * 06/21/2021
 * a customer class that extends the abstract customer class and inherits its variables
*/
package finalProject;

public class customer extends abstractCustomer{
	
	//declare an integer variable that holds the floor number
	static double numOfFloor;
	//declare a boolean variable for the parking spot
	static boolean ParkingSpot;
	//declare a boolean variable for furnishing
	static boolean Furnished;
	
	/*
	 * sree jessu
	 * calculatePrice
	 * 06/21/2021
	 * calculates the price of each room
	 */
	public void calculatePrice(){
		price = (200 * numOfFloor) + (numOfBeds * daysStayed * 10);
	}
	
	/*
	 * sree jessu
	 * parkingSpot
	 * 06/21/2021
	 * checks if there is a parking spot and finds the price
	 */
	public static boolean parkingSpot(){
		if(ParkingSpot = true){
			price = price + 50;
		}
		else {
			return false;
		}
		return ParkingSpot;		
	}
	
	/*
	 * sree jessu
	 * furnished
	 * 06/21/2021
	 * checks if the room is furnished and finds the price
	 */
	public static boolean furnished(){
		if (Furnished = true){
			price = price + 100;
		}
		else {
			return false;
		}
		return Furnished;
	}
	
	/*
	 * sree jessu
	 * customer
	 * 06/21/2021
	 * stores all the required variables for the hotel room
	 */
	customer(double floor, double beds, boolean parking, boolean furniture){	
		numOfFloor = floor;
		numOfBeds = beds;
		parking = parkingSpot();
		furniture = furnished();
		calculatePrice();
	}

}
