/*
 * sree jessu
 * hotelCustomer
 * 06/17/2021
 * allows manager to access various functions
 * input: role as manager
 * output: desired function
*/
package finalProject;

import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import finalProject.customer;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class hotelCustomer extends JFrame implements ActionListener {
	
	//create a table with column labels for rooms
	static Object[] columns = {"Floor", "Beds", "Parking", "Furniture", "Days"};
	
	//create an array of objects
	static final Object[] row = new Object[5];
	
	//declare and initialize a table of employee values
	static final JTable table = new JTable();
	
	public static void main(String[] args) throws IOException{
		//creates a new GUI window
		hotelCustomer window = new hotelCustomer();
		//allows user to exit GUI when it is closed
	    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    //title of the GUI window
	    window.setTitle("Hotel Customer");
	    //size of the GUI window
	    window.setSize(800,600);
	    //boolean that makes the GUI window visible
	    window.setVisible(true); 
	}
	
	/*
	 * sree jessu
	 * hotelCustomer
	 * 06/21/2021
	 * a method that creates the menu for the customer and the click-able options in it
	*/
	public hotelCustomer(){		
		//declare JMenuBar, JMenu, and JMenuItem variables
		JMenuBar menuBar;
	    JMenu menu;
	    JMenuItem menuItem;
	    
	    //create a new JMenuBar object
	    menuBar = new JMenuBar();
	    setJMenuBar(menuBar);
	    //name the new menu "Services"
	    menu = new JMenu("Services");
	    //add the menu option to the menu bar
	    menuBar.add(menu);
	    
	    //create a new menu item known as Room Information
	    menuItem = new JMenuItem("Room Information");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);
	    
	    //create a new menu item known as Room Information
	    menuItem = new JMenuItem("Room Calculation");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);	    
	    
	    //create a new menu item known as Save Information
	    menuItem = new JMenuItem("Save Information");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);
	    
	    //create a new menu item known as Recreational Activities
	    menuItem = new JMenuItem("Recreational Activities");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);    	    	  
	    
	    //create a new menu item known as Tourist Attractions
	    menuItem = new JMenuItem("Tourist Attractions");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);	
	    	    
	    //create a new menu item known as Quit
	    menuItem = new JMenuItem("Quit");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);	    
	}
	
	/*
	 * sree jessu
	 * roomInfo
	 * 06/21/2021
	 * a method that gives the information of rooms
	*/	
	public static void roomInfo(){
		//create a new frame for the panel
		JFrame frame = new JFrame();
		//create a new panel for the label
		JPanel panel = new JPanel();
						
		//create JLabels to show what information to add
		final JLabel rooms = new JLabel();
		final JLabel roomList = new JLabel();
		
		//add room title label
		rooms.setText("Room List");
		//add room list label with list of rooms
		roomList.setText("<html>Floor 1; 1 Bed; No PS; No Furniture<br>"
				+ "Floor 1; 2 Beds; No PS; Furniture<br>"
				+ "Floor 1; 2 Beds; No PS; Furniture<br>"
				+ "Floor 1; 3 Beds; PS; No Furniture<br>"
				+ "Floor 2; 2 Beds; No PS; No Furniture<br>"
				+ "Floor 2; 2 Beds; No PS; Furniture<br>"
				+ "Floor 2; 3 Beds; PS; Furniture<br>"
				+ "Floor 2; 4 Beds; PS; No Furniture<br>"
				+ "Floor 2; 4 Beds; PS; Furniture<br>"
				+ "Floor 3; 3 Beds; No PS; No Furniture<br>"
				+ "Floor 3; 3 Beds; PS; Furniture<br>"
				+ "Floor 3; 4 Beds; PS; No Furniture<br>"
				+ "Floor 3; 4 Beds; PS; No Furniture<br>"
				+ "Floor 3; 5 Beds; No PS; Furniture<br>"
				+ "Floor 4; 3 Beds; PS; Furniture<br>"
				+ "Floor 4; 3 Beds; PS; No Furniture<br>"
				+ "Floor 4; 5 Beds; No PS; Furniture<br>"
				+ "Floor 4; 5 Beds; PS; No Furniture<br>"
				+ "Floor 5; 4 Beds; PS; Furniture<br>"
				+ "Floor 5; 4 Beds; PS; Furniture<br>"
				+ "Floor 5; 4 Beds; No PS, Furniture<br>"
				+ "Floor 5; 6 Beds; PS; No Furniture</html>");
										
		//set the bounds for each of the information fields
		rooms.setBounds(100, 100, 100, 100);
		roomList.setBounds(100, 150, 400, 400);
						
		//add the label fields to the frame
		frame.add(rooms);
		frame.add(roomList);
						
		//add the scroll pane to the frame				
		frame.add(panel);
						
		//set the frame size
		frame.setSize(500, 500);		 
		frame.show();
	}

	/*
	 * sree jessu
	 * roomCalc
	 * 06/21/2021
	 * a method that gives the price of the room selected
	*/	
	public static void roomCalc(){
		//create JFrame
		JFrame frame = new JFrame();		
		
		//create a default table model
		final DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columns);

		//set the model to the table
		table.setModel(model);
		//set background colors
		table.setBackground(Color.CYAN.brighter());
		//set foreground colors
		table.setForeground(Color.black);
		//create a font
		Font font = new Font("", 1, 18);
		//set the font to the table
		table.setFont(font);
		//set the row height
		table.setRowHeight(30);		

		
		//create JLabels to show what information to add
		final JLabel floorLab = new JLabel();
		floorLab.setText("Floor Number");
		final JLabel bedsLab = new JLabel();
		bedsLab.setText("Number of Beds");
		final JLabel parkingLab = new JLabel();
		parkingLab.setText("Parking Spot");
		final JLabel furnitureLab = new JLabel();
		furnitureLab.setText("Furniture");
		final JLabel daysLab = new JLabel();
		daysLab.setText("Days Stayed");

		//create JTextFields to hold the room information
		final JTextField floor = new JTextField();
		final JTextField beds = new JTextField();
		final JTextField parking = new JTextField();
		final JTextField furniture = new JTextField();
		final JTextField days = new JTextField();

		//create button that helps add, edit, delete, and calculate the room information
		JButton btnCalcPrice = new JButton("Calculate Price");
		JButton btnAdd = new JButton("Add");
		JButton btnEdit = new JButton("Edit");
		JButton btnDelete = new JButton("Delete");
		
		//set the bounds for each of the information fields
		floorLab.setBounds(10, 220, 100, 25);
		bedsLab.setBounds(10, 250, 100, 25);
		parkingLab.setBounds(10, 280, 100, 25);
		furnitureLab.setBounds(10, 310, 100, 25);
		daysLab.setBounds(10, 340, 100, 25);
		
		//set the bounds for each of the information fields
		floor.setBounds(150, 220, 100, 25);
		beds.setBounds(150, 250, 100, 25);
		parking.setBounds(150, 280, 100, 25);
		furniture.setBounds(150, 310, 100, 25);
		days.setBounds(150, 340, 100, 25);

		//set the bounds for each of the buttons
		btnCalcPrice.setBounds(300, 240, 100, 25);
		btnAdd.setBounds(300, 270, 100, 25);
		btnEdit.setBounds(300, 300, 100, 25);
		btnDelete.setBounds(300, 330, 100, 25);
		

		//create a JScrollPane to make a scrollable table
		JScrollPane pane = new JScrollPane(table);
		//set the bounds of the table
		pane.setBounds(0, 0, 880, 200);
		//make the frame layout null
		frame.setLayout(null);
		//add the scroll pane to the frame
		frame.add(pane);

		//add the label fields to the frame
		frame.add(floorLab);
		frame.add(bedsLab);
		frame.add(parkingLab);
		frame.add(furnitureLab);
		frame.add(daysLab);
				
		//add the text fields to the frame
		frame.add(floor);
		frame.add(beds);
		frame.add(parking);
		frame.add(furniture);
		frame.add(days);

		//add the buttons to the frame
		frame.add(btnCalcPrice);
		frame.add(btnAdd);
		frame.add(btnEdit);
		frame.add(btnDelete);
			
		/*
		 * sree jessu
		 * actionPerformed for price button
		 * 06/17/2021
		 * a method that calculates the room price
		*/
		btnCalcPrice.addActionListener(new ActionListener(){						
			@Override
			public void actionPerformed(ActionEvent e){
				//declare a label that prints the cost
				final JLabel totalPrice = new JLabel();
				
				//convert the user entered values to a double value
				double numOfFloor = Double.parseDouble(floor.getText());
				double numOfBeds = Double.parseDouble(beds.getText());
				double stay = Double.parseDouble(days.getText());
				
				//save the string for parking into a variable				
				String parkingAns = parking.getText();
	        	String furnAns = furniture.getText();
	        	
	        	//equal the boolean values to the methods from the customer class
	        	boolean parkSpot = customer.parkingSpot();
	        	boolean furn = customer.furnished();
	        	
	        	double price = (200 * numOfFloor) + (numOfBeds * stay * 10);
	        	//check if a parking spot is provided
	        	if(parkingAns.trim().equals("yes")){
	        		//parkSpot boolean is true
	        		parkSpot = true;
	        		//add 50 dollars to the price
	        		price += 50;
	        		if(furnAns.trim().equals("yes")){
	        			//furn boolean is true
	        			furn = true;
	        			//add 100 dollars to the price
		        		price += 100;
		        	}else if(furnAns.trim().equals("no")){
		        		//furn boolean is false
		        		furn = false;
		        		price += 0;
		        	}else{
		        		totalPrice.setText("Invalid Input...");
		        	}
	        		//print the price
		        	totalPrice.setText("The Total Price is: $" + price + ".");
	        	}else if(parkingAns.trim().equals("no")){
	        		//parkSpot boolean is false
	        		parkSpot = false;
	        		price += 0;
	        		if(furnAns.trim().equals("yes")){
	        			//furn boolean is true
	        			furn = true;
	        			//add 100 dollars to the price
		        		price += 100;
		        	}else if(furnAns.trim().equals("no")){
		        		//furn boolean is false
		        		furn = false;
		        		price += 0;
		        	}else{
		        		totalPrice.setText("Invalid Input...");
		        	}
	        		//print the price
		        	totalPrice.setText("The Total Price is: $" + price + ".");
	        	}
	        	else{
	        		totalPrice.setText("Invalid Input...");
	        	}
	        	
	        	
	        	//add label to frame and set bounds
	        	frame.add(totalPrice);
	        	totalPrice.setBounds(10, 350, 200, 100);
			}
		});
		
		/*
		 * sree jessu
		 * actionPerformed for add button
		 * 06/17/2021
		 * a method for the add button that adds row to the table when clicked
		*/
		btnAdd.addActionListener(new ActionListener(){						
			@Override
			public void actionPerformed(ActionEvent e){
				//add the information typed in the text field to the rows
				row[0] = floor.getText();
				row[1] = beds.getText();
				row[2] = parking.getText();
				row[3] = furniture.getText();
				row[4] = days.getText();
				
				//add the new row to the model
				model.addRow(row);				
			}
		});

		/*
		 * sree jessu
		 * actionPerformed for delete button
		 * 06/17/2021
		 * a method for the delete button that deletes a row from the table when clicked
		*/
		btnDelete.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				//initialize and declare a variable i for the index of the selected row
				int i = table.getSelectedRow();
				if(i >= 0){
					//removes a row from the table
					model.removeRow(i);
				}else{
					System.out.print("Sorry! No room was selected.");				
				}
			}
		});

		/*
		 * sree jessu
		 * mouseListener for delete button 
		 * 06/17/2021
		 * a mouse clicker method for the delete button 
		*/
		table.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e){
				//initialize and declare a variable i for the index of the selected row
				int i = table.getSelectedRow();
				
				//set the values for the deleted contact to empty
				floor.setText(model.getValueAt(i, 0).toString());
				beds.setText(model.getValueAt(i, 1).toString());
				parking.setText(model.getValueAt(i, 2).toString());
				furniture.setText(model.getValueAt(i, 3).toString());
				days.setText(model.getValueAt(i, 4).toString());
			}
		});

		/*
		 * sree jessu
		 * actionPerformed for edit
		 * 06/17/2021
		 * a method for the view button that allows the user to click on a row and change values
		*/
		btnEdit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				//initialize and declare a variable i for the index of the selected row
				int i = table.getSelectedRow();
				//if the row is 0 or above, update the row
				if (i >= 0){
					model.setValueAt(floor.getText(), i, 0);
					model.setValueAt(beds.getText(), i, 1);
					model.setValueAt(parking.getText(), i, 2);
					model.setValueAt(furniture.getText(), i, 3);
					model.setValueAt(days.getText(), i, 4);
				}else{
					//if it is less than 0, print error statement 
					System.out.println("Edit Error");
				}
			}
		});

		//frame parameters
		frame.setSize(900, 400);
		//frame location
		frame.setLocationRelativeTo(null);
		//allows user to exit the application after clicking the x
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//makes sure the frame can be seen
		frame.setVisible(true);				
	}
	
	/*
	 * sree jessu
	 * saveInfo
	 * 06/17/2021
	 * method prints entries in the file
	 * input: n/a
	 * output: saves information in file
	 */
	public static void saveInfo() throws IOException{
		//create a new frame for the panel
		JFrame frame = new JFrame();
		//create a new panel for the save message label
		JPanel panel = new JPanel();
		//create a new label that gives the save message
		final JLabel saveMessage = new JLabel();
		
		//declare and initialize the print writer
		PrintWriter output = new PrintWriter(new FileWriter("roomInformation.txt"));
		//print the contents of the table
		output.println(row.length);
		//goes through each entry and prints it in the file
		for(int i = 0; i < row.length; i++){	
			output.println(row[i]);
		}
		//label that sends a message that the information is being saved to the account
		saveMessage.setText("Saving Information ...");
		//add the label to the panel
		panel.add(saveMessage);
		//add the panel to the frame
		frame.add(panel);
		
		//set the frame size
		frame.setSize(100, 100);		 
        frame.show();
		//closes file
		output.close();
	}
	
	/*
	 * sree jessu
	 * recAct
	 * 06/17/2021
	 * method displays list of recreational activities
	 * input: n/a
	 * output: displays list of recreational activities
	 */
	public static void recAct() throws IOException{
		//create a new frame for the panel
		JFrame frame = new JFrame();
		//create a new panel for the label
		JPanel panel = new JPanel();
		
		//create JLabels to show what information to add
		final JLabel pool = new JLabel();
		//add pool label and timings
		pool.setText("<html>Pool Hours<br>"
				+ "Monday: 8:00 am - 7:30 pm<br>"
				+ "Tuesday: 8:00 am - 7:30 pm<br>"
				+ "Wednesday: 8:00 am - 7:30 pm<br>"
				+ "Thursday: 8:00 am - 7:30 pm<br>"
				+ "Friday: 8:00 am - 7:30 pm<br>"
				+ "Saturday: 8:30 am - 10:00 pm<br>"
				+ "Sunday: 8:30 am - 10:00 pm</html>");
		//add restaurants label and list
		final JLabel restaurants = new JLabel();
		restaurants.setText("<html>Restaurants Near Me<br>"
				+ "Chick Fil A: 1 km<br>"
				+ "Chatime: 2 km <br>"
				+ "Swiss Chalet: 3.5 km<br>"
				+ "Kandahar Kabob: 3.5 km<br>"
				+ "Ginger: 4.3 km<br>"
				+ "Paradise: 5.2 km<br>"
				+ "Popeyes: 6 km<br>"
				+ "Pizza Pizza: 8.4 km<br>"
				+ "Sushi Aoi: 10 km</html>");
		//add breakfast label and items
		final JLabel food = new JLabel();
		food.setText("<html>Breakfast Menu<br>"
				+ "Scrambled Eggs<br>"
				+ "Waffles<br>"
				+ "Oatmeal<br>"
				+ "Baked Potatoes<br>"
				+ "Yogurt and Granola<br>"
				+ "Bagels</html>");
		//add spa label and timings
		final JLabel spa = new JLabel();
		spa.setText("<html>Spa Hours<br>"
				+ "Monday: 1:00 pm - 6:00 pm<br>"
				+ "Tuesday: 1:00 pm - 6:00 pm<br>"
				+ "Wednesday: 1:00 pm - 6:00 pm<br>"
				+ "Thursday: 1:00 pm - 6:00 pm<br>"
				+ "Friday: 1:00 pm - 6:00 pm<br>"
				+ "Saturday: 11:30 am - 6:30 pm<br>"
				+ "Sunday: 11:30 am - 6:30 pm</html>");
		//add gym label and timings
		final JLabel gym = new JLabel();
		gym.setText("<html>Gym Hours<br>"
				+ "Monday: 8:00 am - 9:30 pm<br>"
				+ "Tuesday: 8:00 am - 9:30 pm<br>"
				+ "Wednesday: 8:00 am - 9:30 pm<br>"
				+ "Thursday: 8:00 am - 9:30 pm<br>"
				+ "Friday: 8:00 am - 9:30 pm<br>"
				+ "Saturday: 8:30 am - 7:00 pm<br>"
				+ "Sunday: 8:30 am - 7:00 pm</html>");
		
		//set the bounds for each of the information fields
		pool.setBounds(100, 100, 200, 200);
		restaurants.setBounds(100, 265, 200, 200);
		food.setBounds(100, 420, 200, 200);
		spa.setBounds(100, 560, 200, 200);
		gym.setBounds(100, 710, 200, 200);
		
		//add the label fields to the frame
		frame.add(pool);
		frame.add(restaurants);
		frame.add(food);
		frame.add(spa);
		frame.add(gym);	
		
		//add the scroll pane to the frame				
		frame.add(panel);
		
		//set the frame size
		frame.setSize(1000, 1000);		 
	    frame.show();
	}
	
	/*
	 * sree jessu
	 * tourAtt
	 * 06/17/2021
	 * method displays list of tourist attractions
	 * input: n/a
	 * output: displays list of tourist attractions
	 */
	public static void tourAtt() throws IOException{
		//create a new frame for the panel
		JFrame frame = new JFrame();
		//create a new panel for the label
		JPanel panel = new JPanel();
				
		//create JLabels to show what information to add
		final JLabel tourism = new JLabel();
		final JLabel tourismList = new JLabel();
		//add tourism title label
		tourism.setText("Tourist Attractions");
		//add tourism list label with list of attractions
		tourismList.setText("<html>Wax Museum: 1 km <br>"
				+ "Jameson Park: 0.5 km<br>"
				+ "Hilton Waterfalls: 2 km <br>"
				+ "Rocky Mountains: 3.5 km<br>"
				+ "Fear Haunted House: 4.7 km<br>"
				+ "4D Theater: 6 km<br>"
				+ "Cherry Blossom Festival: 8.2 km<br>"
				+ "Bounty's Playhouse: 16 km<br>"
				+ "Wilson County Fair: 20 km</html>");
								
		//set the bounds for each of the information fields
		tourism.setBounds(100, 100, 200, 200);
		tourismList.setBounds(100, 200, 200, 200);
				
		//add the label fields to the frame
		frame.add(tourism);
		frame.add(tourismList);
				
		//add the scroll pane to the frame				
		frame.add(panel);
				
		//set the frame size
		frame.setSize(350, 400);		 
		frame.show();
	}

	/*
	 * sree jessu
	 * actionPerformed
	 * 06/17/2021
	 * method corresponds the user clicked option to a method
	 * input: menu option
	 * output: function(method) corresponding to the option
	 */
	@Override
	public void actionPerformed(ActionEvent e){
	    String event = e.getActionCommand();
	    //menu items and corresponding method response
	    if(event.equals("Quit")){
	      hide();
	      System.exit(0);
	    }else if(event.equals("Room Information")){
	    	roomInfo();
	    }else if(event.equals("Room Calculation")){
	    	roomCalc();
	    }else if(event.equals("Save Information")){
	    	try{
	    		saveInfo();
			} catch (IOException e1){				
				e1.printStackTrace();
				System.out.println("Error - program crashed " + e1);
			}
	    }else if(event.equals("Recreational Activities")){
	    	try{
	    		recAct();
			} catch (IOException e1){				
				e1.printStackTrace();
				System.out.println("Error - program crashed " + e1);
			}
	    }else if(event.equals("Tourist Attractions")){
	    	try{
	    		tourAtt();
			} catch (IOException e1){				
				e1.printStackTrace();
				System.out.println("Error - program crashed " + e1);
			}
	    }
	}
}
