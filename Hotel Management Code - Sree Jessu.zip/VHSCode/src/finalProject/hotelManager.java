/*
 * sree jessu
 * hotelManager
 * 06/17/2021
 * allows manager to access various functions
 * input: role as manager
 * output: desired function
*/
package finalProject;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.TableRowSorter;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class hotelManager extends JFrame implements ActionListener{
	
	//create a table with column labels for employees
	static Object[] columns = {"Name", "Address", "Salary", "Employee Code", "Experience"};
	
	//create an array of objects
	static final Object[] row = new Object[5];
	
	//declare and initialize a table of employee values
	static final JTable table = new JTable();
	
	//declare a JPanel for the credentials
	JPanel panel;
	
	//create a label for the username, password, and the message
	JLabel username_label, password_label, message;
	
	//create a text field for the username
	JTextField username_text;
	
	//create a text field for the password
	JPasswordField password_text;
	
	//declare the submit and cancel buttons
	JButton submit, cancel;
	
	public static void main(String[] args) throws IOException{
		//creates a new GUI window
		hotelManager window = new hotelManager();

		//allows user to exit GUI when it is closed
	    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    //title of the GUI window
	    window.setTitle("Hotel Manager");
	    //size of the GUI window
	    window.setSize(300,200);
	    //boolean that makes the GUI window visible
	    window.setVisible(true);  		
	}
	
	/*
	 * sree jessu
	 * hotelManager
	 * 06/17/2021
	 * a method that makes the credential page
	*/
	public hotelManager(){
		//declare and initialize the username label
		username_label = new JLabel();
		username_label.setText("Username: ");
		//declare and initialize the username field
		username_text = new JTextField();
		
		//declare and initialize the password label
	    password_label = new JLabel();
	    password_label.setText("Password :");
	    //declare and initialize the password field
	    password_text = new JPasswordField();
	    
	    //declare and initialize the submit button
	    submit = new JButton("SUBMIT");
	    
	    //declare and initialize a new panel
	    panel = new JPanel(new GridLayout(3, 1));
	    //add the username and password fields to the panel
	    panel.add(username_label);
	    panel.add(username_text);
	    panel.add(password_label);
	    panel.add(password_text);
	    
	    //declare the message label
	    message = new JLabel();
	    
	    //add the message and submit buttons to the panel
	    panel.add(message);
	    panel.add(submit);
	    
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    //add the listeners to components
	    submit.addActionListener(this);
	    //add the panel to the center
	    add(panel, BorderLayout.CENTER);
	    //set the title of the panel
	    setTitle("Please enter your credentials below!");
	    //set the  of the panel
	    setSize(50,50);
	    //set the visibility to true
	    setVisible(true);	      
	    
	    /*
		 * sree jessu
		 * actionPerformed for submit
		 * 06/17/2021
		 * a method for the submit button that allows the user to login
		*/
	    submit.addActionListener(new ActionListener(){	    	
	    @Override
	    	public void actionPerformed(ActionEvent ae){	    	
	    		//allow user to enter username and password
	    		String username = username_text.getText();
	        	String password = password_text.getText();
	        	
	        	//check username and password credibility
	        	if (username.trim().equals("manager") && password.trim().equals("hotel123")){
	        		message.setText("Hello " + username + " !");
	        	}else{
	        		message.setText("Invalid user... ");
	        	}
	        	menu();
	      	}
	    });      
	}
	
	/*
	 * sree jessu
	 * menu
	 * 06/17/2021
	 * a method that creates the menu for the manager and the click-able options in it
	*/
	public void menu(){
		//declare JMenuBar, JMenu, and JMenuItem variables
		JMenuBar menuBar;
	    JMenu menu;
	    JMenuItem menuItem;
	    
	    //create a new JMenuBar object
	    menuBar = new JMenuBar();
	    setJMenuBar(menuBar);
	    //name the new menu "Employees"
	    menu = new JMenu("Employees");
	    //add the menu option to the menu bar
	    menuBar.add(menu);
	    
	    //create a new menu item known as Employee Information
	    menuItem = new JMenuItem("Employee Information");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);	    
	    
	    //create a new menu item known as Save Information
	    menuItem = new JMenuItem("Save Information");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);
	    
	    //create a new menu item known as Load Information
	    menuItem = new JMenuItem("Load Information");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);    	    	  
	    
	    //create a new menu item known as Sort Information
	    menuItem = new JMenuItem("Sort Information");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);	
	    	    
	    //create a new menu item known as Quit
	    menuItem = new JMenuItem("Quit");
	    menuItem.addActionListener(this);
	    //add the menu item to the menu
	    menu.add(menuItem);	    
	}
	
	/*
	 * sree jessu
	 * employeeInfo
	 * 06/17/2021
	 * a method that builds a table where employees can be added, edited, and deleted
	*/	
	public static void employeeInfo(){
		//create JFrame
		JFrame frame = new JFrame();		
		
		//create a default table model
		final DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columns);

		//set the model to the table
		table.setModel(model);
		//set background colors
		table.setBackground(Color.CYAN.brighter());
		//set foreground colors
		table.setForeground(Color.black);
		//create a font
		Font font = new Font("", 1, 18);
		//set the font to the table
		table.setFont(font);
		//set the row height
		table.setRowHeight(30);

		//create JTextFields to hold the employee information
		final JTextField name = new JTextField();
		final JTextField address = new JTextField();
		final JTextField salary = new JTextField();
		final JTextField employeeCode = new JTextField();
		final JTextField experience = new JTextField();

		//create button that helps add the employee information
		JButton btnAdd = new JButton("Add");
		//create button that helps delete the employee information
		JButton btnDelete = new JButton("Delete");
		//create button that helps edit the employee information
		JButton btnEdit = new JButton("Edit");
		
		//set the bounds for each of the information fields
		name.setBounds(20, 220, 100, 25);
		address.setBounds(20, 250, 100, 25);
		salary.setBounds(20, 280, 100, 25);
		employeeCode.setBounds(20, 310, 100, 25);
		experience.setBounds(20, 340, 100, 25);

		//set the bounds for each of the buttons
		btnAdd.setBounds(150, 220, 100, 25);
		btnEdit.setBounds(150, 265, 100, 25);
		btnDelete.setBounds(150, 310, 100, 25);

		//create a JScrollPane to make a scrollable table
		JScrollPane pane = new JScrollPane(table);
		//set the bounds of the table
		pane.setBounds(0, 0, 880, 200);
		//make the frame layout null
		frame.setLayout(null);
		//add the scroll pane to the frame
		frame.add(pane);

		//add the text fields to the frame
		frame.add(name);
		frame.add(address);
		frame.add(salary);
		frame.add(employeeCode);
		frame.add(experience);

		//add the buttons to the frame
		frame.add(btnAdd);
		frame.add(btnDelete);
		frame.add(btnEdit);
			
		/*
		 * sree jessu
		 * actionPerformed for add button
		 * 06/17/2021
		 * a method for the add button that adds row to the table when clicked
		*/
		btnAdd.addActionListener(new ActionListener(){						
			@Override
			public void actionPerformed(ActionEvent e){
				//add the information typed in the text field to the rows
				row[0] = name.getText();
				row[1] = address.getText();
				row[2] = salary.getText();
				row[3] = employeeCode.getText();
				row[4] = experience.getText();
				
				//add the new row to the model
				model.addRow(row);				
			}
		});

		/*
		 * sree jessu
		 * actionPerformed for delete button
		 * 06/17/2021
		 * a method for the delete button that deletes a row from the table when clicked
		*/
		btnDelete.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				//initialize and declare a variable i for the index of the selected row
				int i = table.getSelectedRow();
				if(i >= 0){
					//removes a row from the table
					model.removeRow(i);
				}else{
					System.out.print("Sorry! No employee was selected.");				
				}
			}
		});

		/*
		 * sree jessu
		 * mouseListener for delete button 
		 * 06/17/2021
		 * a mouse clicker method for the delete button 
		*/
		table.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e){
				//initialize and declare a variable i for the index of the selected row
				int i = table.getSelectedRow();
				
				//set the values for the deleted contact to empty
				name.setText(model.getValueAt(i, 0).toString());
				address.setText(model.getValueAt(i, 1).toString());
				salary.setText(model.getValueAt(i, 2).toString());
				employeeCode.setText(model.getValueAt(i, 3).toString());
				experience.setText(model.getValueAt(i, 4).toString());
			}
		});

		/*
		 * sree jessu
		 * actionPerformed for edit
		 * 06/17/2021
		 * a method for the view button that allows the user to click on a row and change values
		*/
		btnEdit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				//initialize and declare a variable i for the index of the selected row
				int i = table.getSelectedRow();
				//if the row is 0 or above, update the row
				if (i >= 0){
					model.setValueAt(name.getText(), i, 0);
					model.setValueAt(address.getText(), i, 1);
					model.setValueAt(salary.getText(), i, 2);
					model.setValueAt(employeeCode.getText(), i, 3);
					model.setValueAt(experience.getText(), i, 4);
				}else{
					//if it is less than 0, print error statement 
					System.out.println("Edit Error");
				}
			}
		});
		//frame parameters
		frame.setSize(900, 400);
		//frame location
		frame.setLocationRelativeTo(null);
		//allows user to exit the application after clicking the x
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//makes sure the frame can be seen
		frame.setVisible(true);				
	}
	
	/*
	 * sree jessu
	 * saveInfo
	 * 06/17/2021
	 * method prints entries in the file
	 * input: n/a
	 * output: saves information in file
	 */
	public static void saveInfo() throws IOException{
		//create a new frame for the panel
		JFrame frame = new JFrame();
		//create a new panel for the save message label
		JPanel panel = new JPanel();
		//create a new label that gives the save message
		final JLabel saveMessage = new JLabel();
		
		//declare and initialize the print writer
		PrintWriter output = new PrintWriter(new FileWriter("information.txt"));
		//print the contents of the table
		output.println(row.length);
		//goes through each entry and prints it in the file
		for(int i = 0; i < row.length; i++){	
			output.println(row[i]);
		}
		//label that sends a message that the information is being saved
		saveMessage.setText("Saving Information ...");
		//add the label to the panel
		panel.add(saveMessage);
		//add the panel to the frame
		frame.add(panel);
		
		//set the frame size
		frame.setSize(100, 100);		 
        frame.show();
		//closes file
		output.close();
	}
	
	/*
	 * sree jessu
	 * loadInfo
	 * 06/17/2021
	 * method writes array values to file
	 * input: array values
	 * output: writes to file
	 */
	public static void loadInfo() throws IOException{
		//create a new frame for the panel
		JFrame frame = new JFrame();
		//create a new panel for the load message label
		JPanel panel = new JPanel();
		//create a new label that gives the load message
		final JLabel loadMessage = new JLabel();
		
		//declare and initialize the buffered reader
		BufferedReader in = new BufferedReader(new FileReader("information.txt"));
		
		//label that sends a message that the information is being loaded
		loadMessage.setText("Loading " + table.getRowCount() + " information...");
		//add the label to the panel
		panel.add(loadMessage);
		//add the panel to the frame
		frame.add(panel);
				
		//set the frame size
		frame.setSize(100, 100);		 
		frame.show();
		
		//goes through each index and takes contact input
		for(int i = 0; i < table.getRowCount(); i++){
			row[i] = in.readLine();
		}
	}
	
	/*
	 * sree jessu
	 * sortInfo
	 * 06/17/2021
	 * method sorts all information in alphabetical order
	 * input: n/a
	 * output: alphabetized information
	 */
	public static void sortInfo() throws IOException{
		//create a new table row sorter
		TableRowSorter<TableModel> sorter = new TableRowSorter<>(table.getModel());
		//set sorter for the rows in the employee table
		table.setRowSorter(sorter);
		//make a new array list named sortKeys
		List<RowSorter.SortKey> sortKeys = new ArrayList<>();
		
		//declare and initialize integer, columnIndexToSort to 1
		int columnIndexToSort = 1;
		sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING));
		
		//set sorter to sortKeys
		sorter.setSortKeys(sortKeys);
		sorter.sort();
	}
												
	/*
	 * sree jessu
	 * actionPerformed
	 * 06/17/2021
	 * method corresponds the user clicked option to a method
	 * input: menu option
	 * output: function(method) corresponding to the option
	 */
	@Override
	public void actionPerformed(ActionEvent e){
	    String event = e.getActionCommand();
	    //menu items and corresponding method response
	    if(event.equals("Quit")){
	      hide();
	      System.exit(0);
	    }else if(event.equals("Employee Information")){
	    	employeeInfo();
	    }else if(event.equals("Save Information")){
	    	try{
	    		saveInfo();
			} catch (IOException e1){				
				e1.printStackTrace();
				System.out.println("Error - program crashed " + e1);
			}
	    }else if(event.equals("Load Information")){
	    	try{
	    		loadInfo();
			} catch (IOException e1){				
				e1.printStackTrace();
				System.out.println("Error - program crashed " + e1);
			}
	    }else if(event.equals("Sort Information")){
	    	try{
				sortInfo();
			} catch (IOException e1){				
				e1.printStackTrace();
				System.out.println("Error - program crashed " + e1);
			}
	    }
	}
}