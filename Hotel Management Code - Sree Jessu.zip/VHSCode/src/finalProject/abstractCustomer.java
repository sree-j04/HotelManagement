/*
 * sree jessu
 * abstractCustomer
 * 06/21/2021
 * a abstract customer class that has variables used in other customer classes
*/
package finalProject;

public abstract class abstractCustomer{
	//declare a variable for the number of beds in the hotel room
	static double numOfBeds;
	//declare a double variable for the price of each hotel
	static double price;
	//declare a integer variable for the time stayed 
	static int daysStayed;
	//declare a integer variable that acts as a counter
	int daysCounter;
	
	/*
	 * sree jessu
	 * calculatePrice
	 * 06/20/2021
	 * calculates the price of each room
	 */
	abstract void calculatePrice();
	
	/*
	 * sree jessu
	 * parkingSpot
	 * 06/20/2021
	 * checks if the room has a parking spot
	 */
	static boolean parkingSpot(){
		return false;	
	}
	
	/*
	 * sree jessu
	 * furnished
	 * 06/20/2021
	 * checks whether or not the room is furnished
	 */
	static boolean furnished(){
		return false;	
	}
}
